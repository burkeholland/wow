(function () {
    
  window.onerror = function (msg, url, line) {
    alert(msg);
  };

  window.APP = {
    models: {
      main: {
        addUser: function (e) {
          console.log('ok');
        }
      }
    },
    events: {
      login: {
        show: function () {
          // navigator.notification.alert('In Wow, everything is tappable. Tap anywhere to see what happens. Seriously, as if you weren\'t going to do that anyway', null, 'Wow!', 'Got it!');
        }
      }
    }
  };

  document.addEventListener('deviceready', function () {

    navigator.splashscreen.hide();

    new kendo.mobile.Application(document.body, { 
      skin: 'flat',
      initial: 'views/login.html'
    });

  });
    
})();